class ImagePath {
  final String _basePath = 'lib/assets/images';
  String get logo => '$_basePath/logo.svg';
  String get logoNav => '$_basePath/logo_nav.svg';
}
