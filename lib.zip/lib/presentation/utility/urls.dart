class Urls {
  static String baseUrl = 'https://fakestoreapi.com/products';
  static String productsUrl = '$baseUrl/products';
}
