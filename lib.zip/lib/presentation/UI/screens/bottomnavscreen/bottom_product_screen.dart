import 'package:crafty_bay_ecommerce_flutter/data/model/product_model.dart';
import 'package:crafty_bay_ecommerce_flutter/data/network/network_caller.dart';
import 'package:crafty_bay_ecommerce_flutter/presentation/UI/widget/product_card.dart';
import 'package:flutter/material.dart';

class BottomProductScreen extends StatelessWidget {
  const BottomProductScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        title: const Text('Products'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: FutureBuilder<List<Product>>(
          future: NetworkCaller().getProducts(), // Fetch products
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            } else if (snapshot.hasError) {
              return Center(child: Text('Error: ${snapshot.error}'));
            } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
              return const Center(child: Text('No products found'));
            }

            final products = snapshot.data!;
            return GridView.builder(
              itemCount: products.length, // Dynamic item count
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                crossAxisSpacing: 8.0,
                mainAxisSpacing: 8.0,
                childAspectRatio: 0.9,
              ),
              itemBuilder: (context, index) {
                return ProductCard(
                    product: products[index]); // Pass product data
              },
            );
          },
        ),
      ),
    );
  }
}
